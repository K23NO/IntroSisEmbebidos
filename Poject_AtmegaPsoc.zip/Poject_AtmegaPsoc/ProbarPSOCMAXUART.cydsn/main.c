#include <project.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX30102_ADDR 0x57

// Registros del sensor
#define REG_INTR_STATUS  0x00
#define REG_FIFO_DATA   0x07
#define REG_MODE_CONFIG 0x09
#define REG_SPO2_CONFIG 0x0A
#define REG_LED1_PA     0x0C
#define REG_LED2_PA     0x0D
#define REG_FIFO_CONFIG 0x08

// Parámetros para cálculo de BPM
#define RATE_SIZE 8
#define BEAT_THRESHOLD 20000
#define BEAT_DEBOUNCE_MS 200

// Buffer para UART
char uartBuffer[50];

// Variables globales
uint32_t lastBeat = 0;
uint32_t beatAvg = 0;
uint32_t rates[RATE_SIZE];
uint8_t rateSpot = 0;

void MAX30102_WriteReg(uint8 reg, uint8 value) {
    uint8 buffer[2] = {reg, value};
    I2C_1_MasterWriteBuf(MAX30102_ADDR, buffer, 2, I2C_1_MODE_COMPLETE_XFER);
    while (I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP);
}

uint8 MAX30102_ReadReg(uint8 reg) {
    uint8 value;
    I2C_1_MasterWriteBuf(MAX30102_ADDR, &reg, 1, I2C_1_MODE_NO_STOP);
    while (I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP);
    I2C_1_MasterReadBuf(MAX30102_ADDR, &value, 1, I2C_1_MODE_REPEAT_START);
    while (I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP);
    return value;
}

void MAX30102_Init() {
    // Reset del sensor
    MAX30102_WriteReg(REG_MODE_CONFIG, 0x40);
    CyDelay(10);
    
    // Configuración FIFO
    MAX30102_WriteReg(REG_FIFO_CONFIG, 0x4F);  // Promedio 4 muestras, FIFO Rollover
    
    // Modo SpO2
    MAX30102_WriteReg(REG_MODE_CONFIG, 0x03);
    
    // Configuración SpO2
    MAX30102_WriteReg(REG_SPO2_CONFIG, 0x27);  // ADC Range 4096, 100 sps
    
    // Corriente para LEDs
    MAX30102_WriteReg(REG_LED1_PA, 0x24);      // 7mA para LED Rojo
    MAX30102_WriteReg(REG_LED2_PA, 0x24);      // 7mA para LED IR
}

uint32_t MAX30102_ReadFIFO() {
    uint8 buffer[3];
    uint8 reg = REG_FIFO_DATA;
    
    // Leer 3 bytes (1 muestra)
    I2C_1_MasterWriteBuf(MAX30102_ADDR, &reg, 1, I2C_1_MODE_NO_STOP);
    while (I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP);
    I2C_1_MasterReadBuf(MAX30102_ADDR, buffer, 3, I2C_1_MODE_REPEAT_START);
    while (I2C_1_MasterStatus() & I2C_1_MSTAT_XFER_INP);
    
    // Combinar bytes (los datos son de 18 bits)
    return (buffer[0] << 16) | (buffer[1] << 8) | buffer[2];
}

uint8_t checkForBeat(uint32_t irValue) {
    static uint32_t lastIrValue = 0;
    static int32_t threshold = BEAT_THRESHOLD;
    static uint32_t lastBeatTime = 0;
    
    // Calcular la derivada (cambio en el valor IR)
    int32_t slope = (int32_t)irValue - (int32_t)lastIrValue;
    lastIrValue = irValue;
    
    // Detectar cuando la pendiente cruza el umbral
    if (slope > threshold && (CySysTickGetValue() - lastBeatTime) > (BEAT_DEBOUNCE_MS * 1000)) {
        lastBeatTime = CySysTickGetValue();
        return 1;
    }
    return 0;
}

int main() {
    CyGlobalIntEnable;
    I2C_1_Start();
    UART_1_Start();
    
    MAX30102_Init();
    
    // Inicializar buffer de ritmos
    for(int i = 0; i < RATE_SIZE; i++) {
        rates[i] = 0;
    }
    
    uint32_t spo2 = 0;
    uint32_t bpm = 0;
    uint32_t irValue, redValue;
    
    while(1) {
        // Leer valores IR y RED
        irValue = MAX30102_ReadFIFO();  // LED IR
        redValue = MAX30102_ReadFIFO(); // LED Rojo
        
        // Detectar latidos
        if (checkForBeat(irValue)) {
            uint32_t delta = CySysTickGetValue() - lastBeat;
            lastBeat = CySysTickGetValue();
            
            // Calcular BPM
            bpm = 60000000 / delta;  // BPM = 60,000,000 μs/min / tiempo entre latidos (μs)
            
            if (bpm < 255 && bpm > 20) {
                rates[rateSpot++] = bpm;
                rateSpot %= RATE_SIZE;
                
                // Calcular promedio
                beatAvg = 0;
                for (int i = 0; i < RATE_SIZE; i++) {
                    beatAvg += rates[i];
                }
                beatAvg /= RATE_SIZE;
            }
        }
        
        // Calcular SpO2 (simplificado - implementación real requiere calibración)
        // Nota: Esta es una aproximación básica, no médicamente precisa
        if (irValue > 0 && redValue > 0) {
            float ratio = (float)redValue / (float)irValue;
            spo2 = (uint32_t)(110 - 25 * ratio); // Fórmula de ejemplo
            if (spo2 > 100) spo2 = 99;
            else if (spo2 < 70) spo2 = 70;
        }
        
        // Enviar datos por UART
        sprintf(uartBuffer, "SpO2: %u%%, BPM: %u\r\n", spo2, beatAvg);
        UART_1_PutString(uartBuffer);
        
        CyDelay(10); // Pequeña pausa para estabilidad
    }
}